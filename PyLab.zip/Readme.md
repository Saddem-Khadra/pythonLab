## After cloning the project

* cd pythonLab

### Install the virtualenv package :

pip install virtualenv

### Create the virtual environment :

virtualenv venv

### Activate the virtual environment :

windows : venv\Scripts\activate  \
linux : source venv/bin/activate

### Install Requirements:

pip install -r requirements.txt

### Run python file:
python file_name.py 
